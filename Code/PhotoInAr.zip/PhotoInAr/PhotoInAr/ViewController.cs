﻿using ARKit;
using Foundation;
using System;
using UIKit;
using SceneKit;

namespace PhotoInAr
{
    public partial class ViewController : UIViewController
    {
        private ARSCNView sceneView;

        public ViewController(IntPtr handle) : base(handle)
        {
            sceneView = new ARSCNView
            {
                AutoenablesDefaultLighting = true,
                //DebugOptions = ARSCNDebugOptions.ShowWorldOrigin
            };

            View.AddSubview(sceneView);
        }

        public override void ViewDidLoad()
        {
            base.ViewDidLoad();
            // Perform any additional setup after loading the view, typically from a nib.
            sceneView.Frame = View.Frame;
        }

        public override void ViewDidAppear(bool animated)
        {
            base.ViewDidAppear(animated);

            sceneView.Session.Run(new ARWorldTrackingConfiguration
            {
                AutoFocusEnabled = true,
                PlaneDetection = ARPlaneDetection.Horizontal,
                LightEstimationEnabled = true,
                WorldAlignment = ARWorldAlignment.GravityAndHeading
            }, ARSessionRunOptions.ResetTracking | ARSessionRunOptions.RemoveExistingAnchors);

            var width = 0.1f;
            var length = 0.1f;

            var image = FromUrl("https://images.squarespace-cdn.com/content/v1/60181a52252a33083aba46b0/1617739143509-OWFIZJOZ65PV57X082XV/ke17ZwdGBToddI8pDm48kNKE5EOiqFYA5zB4wPGd58F7gQa3H78H3Y0txjaiv_0fDoOvxcdMmMKkDsyUqMSsMWxHk725yiiHCCLfrh8O1z5QPOohDIaIeljMHgDF5CVlOqpeNLcJ80NK65_fV7S1UfhXDR1S5pfdAaMFKT1v28Nl9eR4Wbneaz1AK2hlGjMhZJvUU1_vYqAKeSqch7nukg/Tant+Robbe.jpg");

            var material = new SCNMaterial();
            material.Diffuse.Contents = image;
            material.DoubleSided = true;

            var geometry = SCNPlane.Create(width, length);
            geometry.Materials = new[] { material };

            var rootNode = new SCNNode();
            rootNode.Geometry = geometry;

            sceneView.Scene.RootNode.AddChildNode(rootNode);
        }

        private static UIImage FromUrl(string uri)
        {
            using (var url = new NSUrl(uri))
            using (var data = NSData.FromUrl(url))
                return UIImage.LoadFromData(data);
        }

        public override void ViewDidDisappear(bool animated)
        {
            base.ViewDidDisappear(animated);

            sceneView.Session.Pause();
        }

        public override void DidReceiveMemoryWarning()
        {
            base.DidReceiveMemoryWarning();
            // Release any cached data, images, etc that aren't in use.
        }
    }
}