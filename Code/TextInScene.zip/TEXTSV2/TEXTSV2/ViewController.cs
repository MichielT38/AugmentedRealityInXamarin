﻿using ARKit;
using Foundation;
using SceneKit;
using System;
using UIKit;

namespace TEXTSV2
{
    public partial class ViewController : UIViewController
    {
        private readonly ARSCNView sceneView;

        public ViewController(IntPtr handle) : base(handle)
        {
            sceneView = new ARSCNView
            {
                AutoenablesDefaultLighting = true,
                DebugOptions = ARSCNDebugOptions.ShowFeaturePoints | ARSCNDebugOptions.ShowWorldOrigin
            };

            View.AddSubview(sceneView);
        }

        public override void ViewDidLoad()
        {
            base.ViewDidLoad();
            // Perform any additional setup after loading the view, typically from a nib.
            sceneView.Frame = View.Frame;
        }

        public override void ViewDidAppear(bool animated)
        {
            base.ViewDidAppear(animated);

            sceneView.Session.Run(new ARWorldTrackingConfiguration
            {
                AutoFocusEnabled = true,
                PlaneDetection = ARPlaneDetection.Horizontal,
                LightEstimationEnabled = true,
                WorldAlignment = ARWorldAlignment.Gravity
            }, ARSessionRunOptions.ResetTracking | ARSessionRunOptions.RemoveExistingAnchors);

            var textNode = new TextNode("Dag robert", UIColor.Green)
            {
                Position = new SCNVector3(0, 0, 0)
            };

            sceneView.Scene.RootNode.AddChildNode(textNode);
        }

        public override void ViewDidDisappear(bool animated)
        {
            base.ViewDidDisappear(animated);

            sceneView.Session.Pause();
        }

        public override void DidReceiveMemoryWarning()
        {
            base.DidReceiveMemoryWarning();
            // Release any cached data, images, etc that aren't in use.
        }

        public class TextNode : SCNNode
        {
            public TextNode(string text, UIColor color)
            {
                var rootNode = new SCNNode
                {
                    Geometry = CreateGeometry(text, color),
                    Position = new SCNVector3(0, 0, 0)
                };

                AddChildNode(rootNode);
            }
        }

        private static SCNGeometry CreateGeometry(string text, UIColor color)
        {
            var geometry = SCNText.Create(text, 0.01f);
            geometry.Font = UIFont.FromName("Courier", 0.5f);
            geometry.Flatness = 0;
            geometry.FirstMaterial.DoubleSided = true;
            geometry.FirstMaterial.Diffuse.Contents = color;
            geometry.FirstMaterial.Specular.Contents = UIColor.Blue;
            return geometry;
        }
    }
}