﻿using ARKit;
using Foundation;
using SceneKit;
using System;
using UIKit;
using CoreGraphics;

namespace ButtonOnCube
{
    public partial class ViewController : UIViewController
    {
        public readonly ARSCNView sceneView;
        public int count;
        
        public ViewController(IntPtr handle) : base(handle)
        {
            sceneView = new ARSCNView
            {
                AutoenablesDefaultLighting = true
            };

            View.AddSubview(sceneView);
        }


        public override void ViewDidLoad()
        {
            base.ViewDidLoad();
            // Perform any additional setup after loading the view, typically from a nib.
            sceneView.Frame = View.Frame;
        }

        public override void ViewDidAppear(bool animated)
        {
            base.ViewDidAppear(animated);

            sceneView.Session.Run(new ARWorldTrackingConfiguration
            {
                AutoFocusEnabled = true,
                LightEstimationEnabled = true,
                WorldAlignment = ARWorldAlignment.Gravity
            }, ARSessionRunOptions.ResetTracking | ARSessionRunOptions.RemoveExistingAnchors);

            var cubeNode = new CubeNode(1f, UIColor.Blue);
            sceneView.Scene.RootNode.AddChildNode(cubeNode);

            UIButton changeButton = new UIButton(UIButtonType.System);
            changeButton.Frame = new CGRect(100, 50, 200, 75);
            changeButton.SetTitle("Switch color", UIControlState.Normal);
            changeButton.BackgroundColor = UIColor.Green;
            changeButton.Layer.CornerRadius = 5f;
            changeButton.TouchUpInside += (sender, e) =>
            {
                count++;
                var material = new SCNMaterial();

                if(count % 2 == 1)
                {
                    material.Diffuse.Contents = UIColor.Red;
                }
                else
                {
                    material.Diffuse.Contents = UIColor.Blue; 
                }

                cubeNode.ChildNodes[0].Geometry.Materials = new SCNMaterial[] { material };
            };

            View.Add(changeButton);
        }

        public override void DidReceiveMemoryWarning()
        {
            base.DidReceiveMemoryWarning();
            // Release any cached data, images, etc that aren't in use.
        }
    }

    public class CubeNode : SCNNode
    {
        public CubeNode(float size, UIColor color)
        {
            var rootnode = new SCNNode
            {
                Geometry = CreateGeometry(size, color)
            };

            AddChildNode(rootnode);
        }

        private static SCNGeometry CreateGeometry(float size, UIColor color)
        {
            var material = new SCNMaterial();

            material.Diffuse.Contents = color;

            var geometry = SCNBox.Create(size, size, size, 0);
            geometry.Materials = new[] { material };

            return geometry;
        }
    }
}