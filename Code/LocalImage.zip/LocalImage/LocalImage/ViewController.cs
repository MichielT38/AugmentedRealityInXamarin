﻿using ARKit;
using Foundation;
using SceneKit;
using System;
using UIKit;

namespace LocalImage
{
    public partial class ViewController : UIViewController
    {
        private readonly ARSCNView sceneView;

        public ViewController(IntPtr handle) : base(handle)
        {
            sceneView = new ARSCNView
            {
                AutoenablesDefaultLighting = true,
            };

            View.AddSubview(sceneView);
        }

        public override void ViewDidLoad()
        {
            base.ViewDidLoad();

            sceneView.Frame = View.Frame;
        }

        public override void ViewDidAppear(bool animated)
        {
            base.ViewDidAppear(animated);

            sceneView.Session.Run(new ARWorldTrackingConfiguration
            {
                AutoFocusEnabled = true,
                PlaneDetection = ARPlaneDetection.Horizontal,
                LightEstimationEnabled = true,
                WorldAlignment = ARWorldAlignment.GravityAndHeading
            }, ARSessionRunOptions.ResetTracking | ARSessionRunOptions.RemoveExistingAnchors);

            // Lesson: Add image to plane
            var size = 0.6f;
            var distanceAway = 1f;

            var frontPlane = new PlaneNode(size)
            {
                Position = new SCNVector3(distanceAway, 0, 0)
            };

            var backPlane = new PlaneNode(size)
            {
                Position = new SCNVector3(-distanceAway, 0, 0)
            };

            var rightPlane = new PlaneNode(size)
            {
                Position = new SCNVector3(0, 0, distanceAway)
            };

            var leftPlane = new PlaneNode(size)
            {
                Position = new SCNVector3(0, 0, -distanceAway)
            };

            var abovePlane = new PlaneNode(size)
            {
                Position = new SCNVector3(0, distanceAway, 0)
            };

            var underPlane = new PlaneNode(size)
            {
                Position = new SCNVector3(0, -distanceAway, 0)
            };

            sceneView.Scene.RootNode.AddChildNode(frontPlane);
            sceneView.Scene.RootNode.AddChildNode(backPlane);
            sceneView.Scene.RootNode.AddChildNode(rightPlane);
            sceneView.Scene.RootNode.AddChildNode(leftPlane);
            sceneView.Scene.RootNode.AddChildNode(abovePlane);
            sceneView.Scene.RootNode.AddChildNode(underPlane);
        }

        public override void ViewDidDisappear(bool animated)
        {
            base.ViewDidDisappear(animated);

            sceneView.Session.Pause();
        }

        public override void DidReceiveMemoryWarning()
        {
            base.DidReceiveMemoryWarning();
        }

        public class PlaneNode : SCNNode
        {
            public PlaneNode(float size)
            {
                var rootNode = new SCNNode
                {
                    Geometry = CreateGeometry(size),
                    // Lesson: Makes the node always face the camera
                    Constraints = new[] { new SCNBillboardConstraint() }
                };

                AddChildNode(rootNode);
            }

            private static SCNGeometry CreateGeometry(float size)
            {
                var image = UIImage.FromFile("Images/Logo.png");

                var material = new SCNMaterial();
                material.Diffuse.Contents = image;
                material.DoubleSided = true;

                var geometry = SCNPlane.Create(size, size);
                geometry.Materials = new[] { material };

                return geometry;
            }
        }
    }
}