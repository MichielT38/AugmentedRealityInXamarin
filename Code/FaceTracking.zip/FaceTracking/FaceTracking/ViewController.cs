﻿using ARKit;
using Foundation;
using SceneKit;
using System;
using UIKit;

namespace FaceTracking
{
    public partial class ViewController : UIViewController
    {
        private readonly ARSCNView sceneView;

        public ViewController(IntPtr handle) : base(handle)
        {
            sceneView = new ARSCNView
            {
                AutoenablesDefaultLighting = true,
                Delegate = new SceneViewDelegate()
            };

            View.AddSubview(sceneView);
        }

        public override void ViewDidLoad()
        {
            base.ViewDidLoad();

            sceneView.Frame = View.Frame;
        }

        public override void ViewDidAppear(bool animated)
        {
            base.ViewDidAppear(animated);

            var faceTrackingConfiguration = new ARFaceTrackingConfiguration()
            {
                LightEstimationEnabled = true,
                MaximumNumberOfTrackedFaces = 1
            };

            sceneView.Session.Run(faceTrackingConfiguration);
        }

        public override void ViewDidDisappear(bool animated)
        {
            base.ViewDidDisappear(animated);

            sceneView.Session.Pause();
        }

        public override void DidReceiveMemoryWarning()
        {
            base.DidReceiveMemoryWarning();
        }
    }

    public class SceneViewDelegate : ARSCNViewDelegate
    {
        public override void DidAddNode(ISCNSceneRenderer renderer, SCNNode node, ARAnchor anchor)
        {
            if (anchor is ARFaceAnchor faceAnchor)
            {
                var faceGeometry = ARSCNFaceGeometry.Create(renderer.GetDevice());

                node.Geometry = faceGeometry;
                node.Opacity = 0.8f;
            }
        }

        public override void DidRemoveNode(ISCNSceneRenderer renderer, SCNNode node, ARAnchor anchor)
        {
            if (anchor is ARFaceAnchor)
            {
            }
        }

        public override void DidUpdateNode(ISCNSceneRenderer renderer, SCNNode node, ARAnchor anchor)
        {
            if (anchor is ARFaceAnchor)
            {
                var faceAnchor = anchor as ARFaceAnchor;
                var faceGeometry = node.Geometry as ARSCNFaceGeometry;
                faceGeometry.Update(faceAnchor.Geometry);
            }
        }
    }
}
