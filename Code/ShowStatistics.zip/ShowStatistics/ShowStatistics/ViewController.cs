﻿using ARKit;
using Foundation;
using SceneKit;
using System;
using UIKit;

namespace ShowStatistics
{
    public partial class ViewController : UIViewController
    {
        private readonly ARSCNView sceneView;

        public ViewController(IntPtr handle) : base(handle)
        {
            sceneView = new ARSCNView
            {
                AutoenablesDefaultLighting = true,
                ShowsStatistics = true
            };

            View.AddSubview(sceneView);
        }

        public override void ViewDidLoad()
        {
            base.ViewDidLoad();
            // Perform any additional setup after loading the view, typically from a nib.
            sceneView.Frame = View.Frame;
        }

        public override void ViewDidAppear(bool animated)
        {
            base.ViewDidAppear(animated);

            sceneView.Session.Run(new ARWorldTrackingConfiguration
            {
                AutoFocusEnabled = true,
                LightEstimationEnabled = true,
                WorldAlignment = ARWorldAlignment.Gravity
            }, ARSessionRunOptions.ResetTracking | ARSessionRunOptions.RemoveExistingAnchors);

            var size = 0.05f;

            var cubeNode = new CubeNode(size, UIColor.Red)
            {
                Position = new SCNVector3(0, 0, 0)
            };

            sceneView.Scene.RootNode.AddChildNode(cubeNode);
        }

        public override void ViewDidDisappear(bool animated)
        {
            base.ViewDidDisappear(animated);
            sceneView.Session.Pause();
        }

        public override void DidReceiveMemoryWarning()
        {
            base.DidReceiveMemoryWarning();
            // Release any cached data, images, etc that aren't in use.
        }

        private class CubeNode :SCNNode
        {
            public CubeNode(float size, UIColor color)
            {
                var rootNode = new SCNNode
                {
                    Geometry = CreateGeometry(size, color)
                };

                AddChildNode(rootNode);
            }

            private static SCNGeometry CreateGeometry(float size, UIColor color)
            {
                var material = new SCNMaterial();
                material.Diffuse.Contents = color;
                var geometry = SCNBox.Create(size, size, size, 0);
                geometry.Materials = new[] { material };
                return geometry;
            }
        }
    }
}