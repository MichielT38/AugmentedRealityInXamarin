﻿using ARKit;
using Foundation;
using SceneKit;
using System;
using UIKit;

namespace PeopleOcclusion
{
    public partial class ViewController : UIViewController
    {
        private readonly ARSCNView sceneView;

        public ViewController(IntPtr handle) : base(handle)
        {
            this.sceneView = new ARSCNView
            {
                AutoenablesDefaultLighting = true,
                DebugOptions = ARSCNDebugOptions.ShowWorldOrigin
            };

            this.View.AddSubview(this.sceneView);
        }

        public override void ViewDidLoad()
        {
            base.ViewDidLoad();

            this.sceneView.Frame = this.View.Frame;
        }

        public override void ViewDidAppear(bool animated)
        {
            base.ViewDidAppear(animated);

            var config = new ARWorldTrackingConfiguration();
            config.AutoFocusEnabled = true;
            config.PlaneDetection = ARPlaneDetection.Horizontal;
            config.LightEstimationEnabled = true;
            config.WorldAlignment = ARWorldAlignment.GravityAndHeading;

            if (ARWorldTrackingConfiguration.SupportsFrameSemantics(ARFrameSemantics.PersonSegmentationWithDepth))
            {
                config.FrameSemantics = ARFrameSemantics.PersonSegmentationWithDepth;
            }

            sceneView.Session.Run(config, ARSessionRunOptions.ResetTracking | ARSessionRunOptions.RemoveExistingAnchors);

            var size = 0.25f;
            var cubeNode = new CubeNode(size, UIColor.Green)
            {
                Position = new SCNVector3(0.8f, 0, 0)
            };

            sceneView.Scene.RootNode.AddChildNode(cubeNode);
        }

        public override void ViewDidDisappear(bool animated)
        {
            base.ViewDidDisappear(animated);

            this.sceneView.Session.Pause();
        }

        public override void DidReceiveMemoryWarning()
        {
            base.DidReceiveMemoryWarning();
        }
    }

    public class CubeNode : SCNNode
    {
        public CubeNode(float size, UIColor color)
        {
            var rootNode = new SCNNode
            {
                Geometry = CreateGeometry(size, color)
            };

            AddChildNode(rootNode);
        }

        private static SCNGeometry CreateGeometry(float size, UIColor color)
        {
            var material = new SCNMaterial();
            material.Diffuse.Contents = color;

            var geometry = SCNBox.Create(size, size, size, 0);
            geometry.Materials = new[] { material };

            return geometry;
        }
    }
}
